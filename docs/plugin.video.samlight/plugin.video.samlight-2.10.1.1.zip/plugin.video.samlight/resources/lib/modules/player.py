# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import xbmcplugin
import json
import time
from threading import Thread
from apis.trakt_api import make_trakt_slug
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, slow_hosts, watched_status as ws
# logger = ku.logger

PROP_RESOLVE_CANCEL = 'redlight.resolve_cancelled'
PROP_PLAY_OPENING = 'redlight.play_opening'
PROP_NEXTEP_PENDING = 'redlight.nextep_pending'
PROP_NEXTEP_PREP_SCHEDULED = 'redlight.nextep_prep_scheduled'
PROP_NEXTEP_PREP_DECLINED = 'redlight.nextep_prep_declined'
PROP_AUTOSCRAPE_NEXTEP_READY = 'redlight.autoscrape_nextep_ready'
PROP_NEXTEP_AUTOPLAY_CANCELLED = 'redlight.nextep_autoplay_cancelled'
PROP_NEXTEP_NATURAL_END = 'redlight.nextep_natural_end'
PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS = 'redlight.random_continual_skip_attempts'
PROP_ACTIVE_PLAYBACK_KEY = 'redlight.active_playback_key'
_NEXTEP_NATURAL_END_SEC = 15
# Movies-only: fire stingers alert ~3 min before other alert sources would (typical 90% vs 95% gap on ~1 hr).
_STINGER_EARLY_OFFSET_SEC = 180
_NEXTEP_SUB_FETCH_DEFER_SEC = 45
_NEXTEP_CLOSE_EARLY_PLAY_SEC = 4
_NEXTEP_CLOSE_POLL_MS = 250
_INTRO_SKIP_PROMPT_EARLY_SEC = 15
_INTRO_SKIP_PROMPT_COUNTDOWN_SEC = 15
_INTRO_SKIP_EARLY_START_SEC = 120
_INTRO_SKIP_SETTLE_SEC = 4
_INTRO_SKIP_SETTLE_MAX_WAIT_SEC = 12
_INTRO_SKIP_SETTLE_JUMP_SEC = 20
_INTRO_CHAPTER_MIN_SEGMENT_SEC = 10
_INTRO_CHAPTER_MIN_END_SEC = 15
_INTRO_SKIP_POST_END_GRACE_SEC = 20
_INTRO_SKIP_SEEK_SETTLE_MS = 250
# Mid-playback stream drop (network loss): Kodi ends the file this far before the real
# end, or the picture freezes this long while not paused.
_DROP_MIN_REMAINING_SEC = 300
_STALL_SEC = 30
_RECONNECT_MAX = 5
_RECONNECT_NETWORK_WAIT_SEC = 20

class RedLightPlayer(xbmc.Player):
	def __init__ (self):
		xbmc.Player.__init__(self)

	def _resolve_cancelled(self):
		if not self.is_generic and (self.sources_object._resolve_user_cancelled or self.sources_object.cancel_all_playback):
			return True
		return ku.get_property(PROP_RESOLVE_CANCEL) == 'true'

	def _autoscrape_handoff_ready(self):
		# Toast is only the last alert window. Confirm + finished scrape already
		# arms Ready (PROP set) — Stop then is a handoff, not "stopped early".
		try:
			if ku.get_property(ku.PROP_AUTOSCRAPE_TOAST_SHOWN) == 'true':
				return True
			ready = ku.get_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			return bool(ready) and ready != 'false'
		except Exception:
			return False

	def _maybe_show_nextep_handoff_cover(self):
		if not getattr(self, 'autoscrape_nextep', False):
			return
		if not self._autoscrape_handoff_ready():
			return
		try:
			from modules.sources import nextep_handoff_cancelled, show_nextep_handoff_cover
			if nextep_handoff_cancelled():
				return
			show_nextep_handoff_cover()
		except Exception:
			pass

	def onPlayBackStopped(self):
		self._playback_end_seen = True
		# A stop Red Light made itself on a frozen stream is not the user's.
		if not getattr(self, '_stall_stopping', False): self._user_stopped = True
		self._maybe_show_nextep_handoff_cover()

	def onPlayBackEnded(self):
		self._playback_end_seen = True
		self._playback_ended = True
		self._maybe_show_nextep_handoff_cover()

	def run(self, url=None, obj=None):
		ku.hide_busy_dialog()
		self.clear_playback_properties(clear_navigation=False)
		if not url:
			self.is_generic = obj == 'video'
			return self.run_error('No playable link was returned.')
		try: return self.play_video(url, obj)
		except:
			self.is_generic = obj == 'video'
			return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		if not self.is_generic and self._resolve_cancelled():
			self.playback_successful = False
			self.cancel_all_playback = True
			self.sources_object.cancel_all_playback = True
			self.sources_object._resolve_user_cancelled = True
			try:
				self.sources_object._abort_plugin_resolve()
			except Exception:
				pass
			return
		ku.volume_checker()
		ku.set_property(PROP_PLAY_OPENING, 'true')
		listitem = self.make_listing()
		# Kodi 22 home widgets / PlayMedia expect setResolvedUrl(); Player().play() from a
		# plugin is unsupported and leaves the original plugin:// item unresolved →
		# "One or more items failed to play" after stop. Fall back to play() when there is
		# no resolve handle (RunPlugin, background nextep), Autoscrape nextep handoff
		# (spent prior-episode handle), or the handle was already used by an earlier
		# source in this scrape (multi-resolve queue).
		if not self._play_via_resolved_url(listitem):
			if self.is_generic:
				ku.clear_video_playlist()
			self.play(self.url, listitem)
		if self.is_generic:
			self.check_playback_start_generic()
			if self.playback_successful:
				ku.clear_property(PROP_PLAY_OPENING)
			else:
				self.safe_stop()
				return self.run_error()
		else:
			self.check_playback_start()
			if self.playback_successful:
				ku.clear_property(PROP_PLAY_OPENING)
				try:
					if self.sources_object:
						self.sources_object.playback_successful = True
						self.sources_object._release_resolve_busy()
						self.sources_object._release_sources_busy()
						# Saved at start, not stop, so a crash still keeps it.
						self.sources_object._remember_played_source()
				except:
					pass
				self._seek_to_resume_if_needed()
				self._register_active_playback()
				self.monitor()
			else:
				self.sources_object.playback_successful = self.playback_successful
				cancelled = self.cancel_all_playback or self.sources_object._resolve_user_cancelled
				if cancelled:
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
				else:
					self.sources_object.cancel_all_playback = self.cancel_all_playback
				if cancelled:
					if not self.sources_object._resolve_user_cancelled:
						self.kill_dialog()
					try:
						self.sources_object._abort_plugin_resolve()
					except Exception:
						pass
				else:
					# Keep the resolver progress UI so play_file can try the next queued source.
					if not getattr(self, '_source_skipped', False): slow_hosts.mark_slow(self.url)
					self.run_error()
					self._dismiss_kodi_playback_error_dialog()
				self.safe_stop()
		try: del self.kodi_monitor
		except: pass

	def _plugin_handle(self):
		try:
			return int(sys.argv[1])
		except Exception:
			return -1

	def _play_via_resolved_url(self, listitem):
		handle = self._plugin_handle()
		if handle <= 0:
			return False
		if not self.is_generic and getattr(self.sources_object, '_resolved_url_sent', False):
			return False
		# Autoscrape nextep handoff reuses the prior episode's spent PlayMedia handle —
		# setResolvedUrl is a noop; Player.play() must open the first picked source.
		if not self.is_generic and getattr(self.sources_object, '_use_player_play', False):
			return False
		try:
			xbmcplugin.setResolvedUrl(handle, True, listitem)
			if not self.is_generic:
				self.sources_object._resolved_url_sent = True
			self._played_via_resolve = True
			return True
		except Exception:
			return False

	def _seek_to_resume_if_needed(self):
		# setResolvedUrl often ignores StartPercent on Kodi 22 / widget PlayMedia.
		# Wait until duration is known (4K demux can take well over 500ms) then seek.
		if not getattr(self, '_played_via_resolve', False):
			return
		try:
			percent = float(self.playback_percent or 0)
		except Exception:
			return
		if percent <= 0:
			return
		try:
			total = 0.0
			for _ in range(40):  # ~10s @ 250ms — matches slow HEVC open, not endless
				if self._resolve_cancelled():
					return
				try:
					if self.isPlayingVideo():
						total = float(self.getTotalTime() or 0)
						if total > 0:
							break
				except Exception:
					pass
				ku.sleep(250)
			if total <= 0:
				try:
					ku.logger('Red Light', 'Resume seek skipped: no duration yet (percent=%s)' % percent)
				except Exception:
					pass
				return
			target = total * percent / 100.0
			try:
				current = float(self.getTime() or 0)
			except Exception:
				current = 0.0
			if current >= target - 5:
				return
			self.seekTime(target)
			try:
				ku.logger('Red Light', 'Resume seek applied: %s%% -> %.1fs (was %.1fs / %.1fs)' % (
					percent, target, current, total))
			except Exception:
				pass
		except Exception:
			pass

	def _dismiss_kodi_playback_error_dialog(self):
		# Kodi shows DialogConfirm (okdialog) when demux/open fails. Force-close so
		# mid-queue resolve retries do not flash a brief confirm over the resolver UI.
		if ku.get_visibility('Window.IsVisible(okdialog)'):
			ku.close_dialog('okdialog')
			return True
		return False

	def check_playback_start_generic(self):
		resolve_percent = 0
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if self.kodi_monitor.abortRequested():
				self.playback_successful = False
				break
			elif resolve_percent >= 100:
				self.playback_successful = False
				break
			elif self._dismiss_kodi_playback_error_dialog():
				self.playback_successful = False
			elif self.isPlayingVideo():
				try:
					if ku.get_property('redlight.browse_playback') == 'true':
						browse_window = getattr(self, '_browse_results_window', None)
						if browse_window:
							try:
								browse_window.selected = (None, '')
								browse_window.close()
								self._browse_results_window = None
							except:
								pass
					if not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
						ku.execute_builtin('ActivateWindow(fullscreenvideo)', block=False)
					if self.getTotalTime() not in ('0.0', '', 0.0, None):
						self.playback_successful = True
				except:
					pass
			resolve_percent = round(resolve_percent + 0.26, 1)
			ku.sleep(50)

	def check_playback_start(self):
		resolve_percent = 0
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if self._resolve_cancelled():
				self.sources_object.cancel_all_playback = True
				self.sources_object._resolve_user_cancelled = True
				self.playback_successful = False
				self.safe_stop()
				break
			elif not self.sources_object.progress_dialog:
				if self._resolve_cancelled():
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
					self.playback_successful = False
					self.safe_stop()
					break
				elif self.isPlayingVideo():
					try:
						if self.getTotalTime() not in ('0.0', '', 0.0, None) and ku.get_visibility('Window.IsActive(fullscreenvideo)'):
							self.playback_successful = True
					except: pass
			elif self.sources_object.progress_dialog.skip_resolved(): self.playback_successful, self._source_skipped = False, True
			elif self.sources_object.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested():
				self.sources_object.cancel_all_playback = True
				self.sources_object._resolve_user_cancelled = True
				self.playback_successful = False
				self.safe_stop()
				break
			elif resolve_percent >= 100:
				self.playback_successful = False
				break
			elif self._dismiss_kodi_playback_error_dialog():
				self.playback_successful = False
			elif self.isPlayingVideo():
				if self._resolve_cancelled():
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
					self.playback_successful = False
					self.safe_stop()
					break
				try:
					if self.getTotalTime() not in ('0.0', '', 0.0, None) and ku.get_visibility('Window.IsActive(fullscreenvideo)'): self.playback_successful = True
				except: pass
			resolve_percent = round(resolve_percent + 0.26, 1)
			try:
				if self.sources_object.progress_dialog:
					self.sources_object.progress_dialog.update_resolver(percent=resolve_percent)
			except: pass
			ku.sleep(50)

	def playback_close_dialogs(self):
		self.sources_object.playback_successful = True
		try:
			from modules.sources import close_nextep_handoff_cover
			close_nextep_handoff_cover()
		except Exception:
			pass
		self.kill_dialog()
		ku.sleep(200)
		try:
			self.sources_object._force_close_sources_overlay_windows()
		except:
			ku.close_all_dialog()

	def monitor(self):
		playback_superseded = False
		self._user_stopped = False
		self._playback_end_seen, self._playback_ended = False, False
		self._stall_stopping, self._stall_detected = False, False
		self._stall_pos, self._stall_since = None, 0.0
		self._reconnect_on_drop = st.reconnect_on_drop()
		try:
			ensure_dialog_dead, total_check_time = False, 0
			if self.media_type == 'episode':
				play_random_continual = self.sources_object.random_continual
				play_random = self.sources_object.random
				disable_autoplay_next_episode = self.sources_object.disable_autoplay_next_episode
				self.num_episodes = getattr(self.sources_object, 'num_episodes', None)
				if disable_autoplay_next_episode: ku.notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
				if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep, self.autoscrape_nextep = False, False
				else: self.autoplay_nextep, self.autoscrape_nextep = self.sources_object.autoplay_nextep, self.sources_object.autoscrape_nextep
				# Play # Episodes: remaining count includes the current episode.
				try: _play_n = int(self.num_episodes) if self.num_episodes not in (None, '') else 0
				except: _play_n = 0
				if _play_n > 1:
					self.autoplay_nextep, self.autoscrape_nextep = True, False
				elif self.num_episodes not in (None, '') and _play_n <= 1:
					self.autoplay_nextep, self.autoscrape_nextep = False, False
				if self.autoplay_nextep or self.autoscrape_nextep:
					self._log_nextep('Next episode monitor active: autoplay=%s autoscrape=%s play_n=%s' % (
						self.autoplay_nextep, self.autoscrape_nextep, self.num_episodes or ''))
				elif st.autoscrape_next_episode() or st.autoplay_next_episode():
					self._log_nextep('Next episode disabled this play (random=%s random_continual=%s custom_values=%s play_n=%s)' % (
						play_random, play_random_continual, disable_autoplay_next_episode, self.num_episodes or ''))
			else:
				self.num_episodes = None
				show_stinger, stinger_alert_timing, stingers_percentage_fallback = st.stingers_show(), st.stingers_alert_timing(), st.stingers_percentage()
				play_random_continual, self.autoplay_nextep, self.autoscrape_nextep = False, False, False
			while total_check_time <= 30 and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.sleep(100)
				total_check_time += 0.10
			ku.hide_busy_dialog()
			ku.sleep(1000)
			self._trakt_scrobble_start()
			self._simkl_scrobble_start()
			self._punchplay_scrobble_start()
			self._wetrakr_scrobble_start()
			self._maybe_start_subtitle_alert_fetch()
			self._maybe_start_introdb_alert_fetch()
			self._intro_skip_fetch_started = False
			if st.auto_enable_subs() and st.subtitles_source() == '0':
				try:
					from indexers.subtitles import enable_local_subtitles, subtitle_notify_poster
					poster = subtitle_notify_poster(self.meta, self.media_type) if getattr(self, 'meta', None) else ku.get_icon('box_office')
					enable_local_subtitles(self, poster=poster, is_episode=self.media_type == 'episode')
				except:
					self.showSubtitles(True)
			# Kodi can report not-playing for a moment while it caches; give it a few seconds.
			for _ in range(30):
				if self.isPlayingVideo() or self.kodi_monitor.abortRequested(): break
				ku.sleep(100)
			loop_ran = False
			while self.isPlayingVideo():
				loop_ran = True
				if not self._owns_active_playback():
					playback_superseded = True
					break
				try:
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					_monitor_sleep_ms = 1000
					if self.media_type == 'episode' and getattr(self, '_nextep_close_wait', False) and not getattr(self, '_nextep_stash_play_scheduled', False):
						try:
							if self._refresh_playback_position():
								_rem = round(float(self.total_time) - float(self.curr_time))
								if 0 < _rem <= 10:
									_monitor_sleep_ms = _NEXTEP_CLOSE_POLL_MS
						except:
							pass
					self._monitor_wait(_monitor_sleep_ms)
					if not self._refresh_playback_position(allow_stale=False):
						if self._playback_end_seen and not self.isPlayingVideo(): continue
						ku.sleep(250)
						continue
					if not self._valid_playback_duration(self.total_time, self.curr_time):
						ku.sleep(250)
						continue
					if self._reconnect_on_drop and self._stream_stalled():
						self._stop_stalled_stream()
						break
					if not getattr(self, '_intro_skip_fetch_started', False):
						self._intro_skip_fetch_started = True
						self._start_intro_skip_fetch()
					self._maybe_apply_intro_skip()
					self._wetrakr_progress_tick()
					self._punchplay_scrobble_progress()
					if play_random_continual:
						if self._should_prep_random_continual():
							self.random_continual_triggered = True
							self.run_random_continual()
							break
					elif self.current_point >= self.watched_tick_percent:
						if not self.media_marked: self.media_watched_marker()
					if self.media_type == 'episode':
						if self.autoplay_nextep or self.autoscrape_nextep:
							if not self.nextep_info_gathered:
								if not self._defer_nextep_info(): self.info_next_ep()
							else:
								self._maybe_refresh_nextep_subtitle_timing()
								self._maybe_refresh_nextep_chapter_timing()
								self._maybe_refresh_nextep_introdb_timing()
							try:
								_nextep_remaining = round(float(self.total_time) - float(self.curr_time))
								if _nextep_remaining > 0: ku.set_property('redlight.nextep_remaining', str(_nextep_remaining))
							except: pass
							if self._should_prep_next_ep(): self._schedule_next_ep()
							self._try_autoplay_nextep_alert()
							self._try_autoplay_early_stash_play()
							self._try_autoscrape_nextep_ready_notify()
							self._maybe_log_nextep_alert_pending()
					elif show_stinger and not self.movie_stingers_run: 
						final_chapter = self._stinger_trigger_point(stinger_alert_timing, stingers_percentage_fallback)
						if self.current_point >= final_chapter: self.run_movie_stingers()
				except: pass
				if not self.subs_searched: self.run_subtitles()
			if not loop_ran and not playback_superseded and not self._user_stopped:
				# The stream died right after it opened (the server stalled, Kodi hit end of
				# file at once). Treat it as a failed start: the loading screen stays up and
				# play_file tries the next source, or closes it when none are left.
				ku.logger('Red Light', 'Playback stopped right after it started: trying the next source')
				slow_hosts.mark_slow(self.url)
				self.playback_successful = False
				self.sources_object._resume_after_failed_start()
				self.clear_playback_properties(clear_navigation=False)
				self._release_active_playback()
				return
			if loop_ran and not playback_superseded and self._reconnect_on_drop and self._stream_dropped():
				if self._reconnect_dropped_stream(): return
			try:
				_remaining = None
				if getattr(self, 'total_time', None) not in (None, '', 0, 0.0) and getattr(self, 'curr_time', None) not in (None, ''):
					_remaining = round(float(self.total_time) - float(self.curr_time))
				natural_end = (not playback_superseded and _remaining is not None and _remaining <= _NEXTEP_NATURAL_END_SEC)
				# After Next Episode Ready, Stop in credits is a deliberate handoff (1.8.2
				# "natural end only" was too strict vs subtitle/IntroDB alert windows).
				ready_fired = self._autoscrape_handoff_ready()
				if self.autoscrape_nextep and not playback_superseded:
					if natural_end or ready_fired:
						ku.set_property(PROP_NEXTEP_NATURAL_END, 'true')
						if ready_fired and not natural_end:
							self._log_nextep('Autoscrape next episode: stop after Ready (remaining=%ss)' % (_remaining if _remaining is not None else '?'))
						try:
							from modules.sources import show_nextep_handoff_cover
							show_nextep_handoff_cover()
						except Exception:
							pass
					else:
						ku.set_property(PROP_NEXTEP_NATURAL_END, 'false')
						try:
							from modules.sources import mark_nextep_autoplay_cancelled
							mark_nextep_autoplay_cancelled()
							self._log_nextep('Autoscrape next episode: cancelled (playback stopped early)')
						except:
							pass
				elif natural_end:
					ku.set_property(PROP_NEXTEP_NATURAL_END, 'true')
			except:
				pass
			autoplay_stash_scheduled = False
			if not playback_superseded and self.autoplay_nextep:
				try:
					from modules.sources import clear_nextep_autoplay_stash, clear_orphan_nextep_play_stash, nextep_autoplay_cancelled, nextep_end_play_superseded, peek_nextep_autoplay_stash, schedule_nextep_stashed_play, take_nextep_autoplay_stash
					if nextep_autoplay_cancelled() or nextep_end_play_superseded():
						clear_nextep_autoplay_stash()
						clear_orphan_nextep_play_stash()
						if nextep_autoplay_cancelled():
							self._log_nextep('Autoplay next episode: skipped at episode end (cancelled)')
						else:
							self._log_nextep('Autoplay next episode: skipped at episode end (superseded by user playback)')
					elif getattr(self, '_nextep_stash_play_scheduled', False):
						autoplay_stash_scheduled = True
					elif getattr(self, '_nextep_alert_shown', False):
						if peek_nextep_autoplay_stash():
							stash = take_nextep_autoplay_stash()
							if stash:
								self._log_nextep('Autoplay next episode: playing stashed resolve at episode end')
								autoplay_stash_scheduled = schedule_nextep_stashed_play(stash)
					else:
						clear_nextep_autoplay_stash()
				except: pass
			if not autoplay_stash_scheduled:
				ku.hide_busy_dialog()
			# Re-sample position before mark — stop often races getTime() (seek then Stop).
			self._refresh_playback_position(allow_stale=True)
			if not playback_superseded and not self.media_marked: self.media_watched_marker()
			# Wipe Kodi MyVideos bookmarks for plugin:// paths so the next home-widget
			# click does not show Resume/Start over before scrape (Umbrella pattern).
			try:
				from modules.watched_status import clear_local_bookmarks
				clear_local_bookmarks()
			except: pass
			self.clear_playback_properties(clear_navigation=False)
			self._release_active_playback()
		except:
			ku.hide_busy_dialog()
			self.sources_object.playback_successful = False
			self.sources_object.cancel_all_playback = True
			return self.kill_dialog()

	def make_listing(self):
		listitem = ku.make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		if self.is_generic:
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('video')
			play_name = ku.get_property('redlight.tb.play_filename') or self.url
			info_tag.setFilenameAndPath(play_name)
			info_tag.setTitle(os.path.basename(play_name) if play_name else '')
			mime = ku.get_property('redlight.tb.play_mime')
			if not mime:
				path_lower = (play_name or self.url or '').lower().split('|')[0].split('?')[0]
				for ext, mt in (
					('.m2ts', 'video/mp2t'), ('.mts', 'video/mp2t'), ('.ts', 'video/mp2t'),
					('.mkv', 'video/x-matroska'), ('.mp4', 'video/mp4'), ('.avi', 'video/x-msvideo'),
					('.mov', 'video/quicktime'), ('.webm', 'video/webm'),
				):
					if path_lower.endswith(ext):
						mime = mt
						break
			if mime:
				try:
					listitem.setMimeType(mime)
				except Exception:
					pass
			self._disable_kodi_url_resume(listitem)
		else:
			self.tmdb_id, self.imdb_id, self.tvdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', ''), self.meta_get('tvdb_id', '')
			self.media_type, self.title, self.year = self.meta_get('media_type'), self.meta_get('title'), self.meta_get('year')
			self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
			poster = self.meta_get('poster') or ku.get_icon('box_office')
			fanart = self.meta_get('fanart') or ku.get_addon_fanart()
			clearlogo = (self.meta_get('clearlogo') or '') if st.show_clearlogo() else ''
			duration, genre, trailer, mpaa = self.meta_get('duration'), self.meta_get('genre', ''), self.meta_get('trailer'), self.meta_get('mpaa')
			rating, votes = self.meta_get('rating'), self.meta_get('votes')
			premiered, studio, tagline = self.meta_get('premiered'), self.meta_get('studio', ''), self.meta_get('tagline')
			director, writer, country = self.meta_get('director', ''), self.meta_get('writer', ''), self.meta_get('country', '')
			cast = self.meta_get('short_cast', []) or self.meta_get('cast', []) or []
			listitem.setLabel(self.title)
			fresh_start = False
			if self.media_type == 'movie':
				plot = self.meta_get('plot') if st.show_loading_plot() else ''
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('movie'), info_tag.setTitle(self.title), info_tag.setOriginalTitle(self.meta_get('original_title')), info_tag.setPlot(plot)
				info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa)
				info_tag.setDuration(duration), info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
				info_tag.setTagLine(tagline), info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre)
				info_tag.setWriters(writer), info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			else:
				if not st.show_loading_plot(): plot = ''
				elif st.avoid_episode_spoilers() and int(self.meta_get('playcount') or 0) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
				else: plot = self.meta_get('plot') or self.meta_get('tvshow_plot')
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(self.meta_get('ep_name')), info_tag.setOriginalTitle(self.meta_get('original_title'))
				info_tag.setTvShowTitle(self.title), info_tag.setTvShowStatus(self.meta_get('status')), info_tag.setSeason(self.season), info_tag.setEpisode(self.episode)
				info_tag.setPlot(plot), info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes)
				info_tag.setMpaa(mpaa), info_tag.setDuration(duration), info_tag.setTrailer(trailer), info_tag.setFirstAired(premiered)
				info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre), info_tag.setWriters(writer)
				info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				fresh_start = self._nextep_aio_en_fresh_start()
				if fresh_start:
					self.playback_percent = 0.0
					try:
						info_tag.setFilenameAndPath('%s S%02dE%02d %s' % (
							self.title or '', int(self.season), int(self.episode), (self.playing_filename or '')[:120]))
					except:
						info_tag.setFilenameAndPath(self.url)
				else:
					info_tag.setFilenameAndPath(self.url)
			self.set_resume_point(listitem)
			if self.url and str(self.url).startswith('http'):
				self._disable_kodi_url_resume(listitem, keep_start_percent=not fresh_start)
			self.set_playback_properties()
		return listitem

	def _trakt_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 1 or not st.trakt_user_active(): return
		from apis.trakt_api import trakt_scrobble, trakt_official_status
		if not trakt_official_status(self.media_type): return
		percent = self.playback_percent if self.playback_percent else 0
		Thread(target=trakt_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode)).start()

	def _trakt_scrobble_stop(self, percent):
		# Synchronous: ending playback tears down the player; a background thread often never finishes, leaving Trakt Playing now stuck.
		if self.is_generic or st.watched_indicators() != 1 or not st.trakt_user_active(): return
		from apis.trakt_api import trakt_scrobble, trakt_official_status
		if not trakt_official_status(self.media_type): return
		try: pct = float(percent or 0)
		except: pct = 0
		# Trakt returns 422 for stop below 1% and leaves watching active — clamp so Playing now still clears.
		if pct < 1: pct = 1
		trakt_scrobble('stop', self.media_type, self.tmdb_id, pct, self.season, self.episode)

	def _simkl_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 2 or not st.simkl_user_active(): return
		from apis.simkl_api import simkl_scrobble, simkl_official_status
		if not simkl_official_status(self.media_type): return
		percent = self.playback_percent if self.playback_percent else 0
		Thread(target=simkl_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode)).start()

	def _simkl_scrobble_stop(self, percent):
		if self.is_generic or st.watched_indicators() != 2 or not st.simkl_user_active(): return
		from apis.simkl_api import simkl_scrobble, simkl_official_status
		if not simkl_official_status(self.media_type): return
		Thread(target=simkl_scrobble, args=('stop', self.media_type, self.tmdb_id, percent, self.season, self.episode)).start()

	def _punchplay_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		import uuid
		self._punchplay_session_id = str(uuid.uuid4())
		self._punchplay_last_progress_send = 0
		percent = self.playback_percent if self.playback_percent else 0
		Thread(target=punchplay_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': self._punchplay_session_id}, daemon=True).start()

	def _punchplay_scrobble_progress(self):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		now = time.time()
		last = getattr(self, '_punchplay_last_progress_send', 0) or 0
		if now - last < 30: return
		self._punchplay_last_progress_send = now
		session_id = getattr(self, '_punchplay_session_id', None)
		Thread(target=punchplay_scrobble, args=('progress', self.media_type, self.tmdb_id, self.current_point, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': session_id}, daemon=True).start()

	def _punchplay_scrobble_stop(self, percent):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		session_id = getattr(self, '_punchplay_session_id', None)
		Thread(target=punchplay_scrobble, args=('stop', self.media_type, self.tmdb_id, percent, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': session_id}, daemon=True).start()

	def _wetrakr_meta_kwargs(self, percent):
		ep_title = ''
		show_title = None
		if self.media_type == 'episode':
			try: ep_title = (self.meta_get('ep_name') if getattr(self, 'meta_get', None) else '') or ''
			except: ep_title = ''
			show_title = getattr(self, 'title', '') or ''
			title = ep_title or show_title
		else:
			title = getattr(self, 'title', '') or ''
		return {
			'progress': percent,
			'title': title,
			'year': getattr(self, 'year', None),
			'tmdb_id': getattr(self, 'tmdb_id', None),
			'imdb_id': getattr(self, 'imdb_id', None),
			'tvdb_id': getattr(self, 'tvdb_id', None),
			'season': getattr(self, 'season', None),
			'episode': getattr(self, 'episode', None),
			'show_title': show_title
		}

	def _wetrakr_send(self, event, percent):
		if self.is_generic or not st.wetrakr_user_active(): return
		from apis.wetrakr_api import wetrakr_should_scrobble, wetrakr_send_event
		if not wetrakr_should_scrobble(): return
		kwargs = self._wetrakr_meta_kwargs(percent)
		Thread(target=wetrakr_send_event, args=(event, self.media_type), kwargs=kwargs).start()

	def _wetrakr_scrobble_start(self):
		self._wetrakr_scrobbled = False
		self._wetrakr_last_progress_send = 0
		percent = self.playback_percent if self.playback_percent else 0
		self._wetrakr_send('playing', percent)

	def _wetrakr_progress_tick(self):
		if self.is_generic or getattr(self, '_wetrakr_scrobbled', False): return
		if not st.wetrakr_user_active(): return
		from apis.wetrakr_api import wetrakr_should_scrobble, wetrakr_scrobble_threshold
		if not wetrakr_should_scrobble(): return
		now = time.time()
		last = getattr(self, '_wetrakr_last_progress_send', 0) or 0
		if now - last >= 30:
			self._wetrakr_last_progress_send = now
			self._wetrakr_send('playing', self.current_point)
		threshold = wetrakr_scrobble_threshold()
		if self.current_point >= threshold and not getattr(self, '_wetrakr_scrobbled', False):
			self._wetrakr_scrobbled = True
			self._wetrakr_send('scrobble', self.current_point)

	def _wetrakr_on_stop(self, percent, force_scrobble=False):
		if getattr(self, '_wetrakr_scrobbled', False): return
		from apis.wetrakr_api import wetrakr_scrobble_threshold
		threshold = wetrakr_scrobble_threshold()
		if force_scrobble or percent >= threshold:
			self._wetrakr_scrobbled = True
			self._wetrakr_send('scrobble', 100 if force_scrobble else percent)
		elif percent >= 5:
			self._wetrakr_send('paused', percent)

	def media_watched_marker(self, force_watched=False):
		self.media_marked = True
		try:
			self._refresh_playback_position(allow_stale=True)
			current_point = getattr(self, 'current_point', 0) or 0
			try:
				ku.logger('Red Light', 'playback stop progress: %.1f%% (curr=%.1fs total=%.1fs)' % (
					float(current_point), float(getattr(self, 'curr_time', 0) or 0), float(getattr(self, 'total_time', 0) or 0)))
			except Exception:
				pass
			tick_at = getattr(self, 'watched_tick_percent', None)
			if tick_at is None: tick_at = st.playback_watched_percent()
			if current_point >= tick_at or force_watched:
				self._trakt_scrobble_stop(100)
				self._simkl_scrobble_stop(100)
				self._punchplay_scrobble_stop(100)
				self._wetrakr_on_stop(100, force_scrobble=True)
				watched_function = ws.mark_movie if self.media_type == 'movie' else ws.mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'tvdb_id': self.tvdb_id, 'from_playback': 'true'}
				Thread(target=self.run_media_progress, args=(watched_function, watched_params), daemon=True).start()
			else:
				# Always stop Trakt live scrobble so Playing now clears. Below ~80% Trakt treats stop as pause + resume.
				self._trakt_scrobble_stop(current_point)
				self._simkl_scrobble_stop(current_point)
				self._punchplay_scrobble_stop(current_point)
				self._wetrakr_on_stop(current_point)
				ku.clear_property('redlight.random_episode_history')
				if current_point >= 5:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': self.curr_time, 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
					# Local DB sync so In Progress is correct even if the remote scrobble
					# thread is still running when the invoker exits; remote stays async.
					try:
						ws.set_bookmark(progress_params, remote=False)
					except Exception:
						pass
					Thread(target=self.run_media_progress, args=(ws.set_bookmark, progress_params), daemon=True).start()
		except: pass

	def run_media_progress(self, function, params):
		try: function(params)
		except: pass

	def _valid_playback_duration(self, total_time=None, curr_time=None):
		try:
			total = total_time if total_time is not None else self.getTotalTime()
			curr = curr_time if curr_time is not None else self.getTime()
			if total in (0, 0.0, '0.0', '', None): return False
			if curr in (0, 0.0, '0.0', '', None): return False
			if float(total) < 60: return False
			return float(curr) > 0
		except:
			return False

	def _player_is_active(self):
		try:
			return self.isPlayingVideo() or self.isPlaying()
		except:
			return False

	def seek(self, seconds, pause_after=False):
		try:
			if not self._player_is_active():
				return False
			seconds = float(seconds)
			total = float(self.getTotalTime())
			if total > 1:
				seconds = max(0.0, min(seconds, total - 1.0))
			self.seekTime(seconds)
			if pause_after:
				self.pause()
			return True
		except:
			return False

	def _log_nextep(self, message):
		try: ku.logger('Red Light', message)
		except: pass

	def _intro_skip_play_type_label(self):
		try:
			play_type = getattr(self.sources_object, 'play_type', '') if getattr(self, 'sources_object', None) else ''
			if play_type in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual'):
				return play_type
		except: pass
		return 'manual'

	def _log_intro_skip(self, message):
		try: ku.logger('Red Light', '%s (play_type=%s)' % (message, self._intro_skip_play_type_label()))
		except: pass

	def _defer_nextep_info(self):
		if getattr(self, 'nextep_info_gathered', False): return False
		nextep_settings = st.auto_nextep_settings(self._nextep_play_type())
		alert_timing = nextep_settings.get('alert_timing')
		if alert_timing == 'introdb':
			if self._outro_credits_pop_at(fetch=False) is not None: return False
			if self._outro_credits_pop_at(fetch=True) is not None: return False
			started = getattr(self, '_playback_started_at', None)
			if started and (time.time() - started) > _NEXTEP_SUB_FETCH_DEFER_SEC: return False
			return True
		if alert_timing != 'subtitles': return False
		if self._subtitle_end_remaining(fetch=False, for_alert=True) is not None: return False
		if not st.subs_alert_fetch_enabled(self.media_type): return False
		if getattr(self, '_subtitle_alert_fetch_done', False): return False
		started = getattr(self, '_playback_started_at', None)
		if started and (time.time() - started) > _NEXTEP_SUB_FETCH_DEFER_SEC: return False
		return True

	def decline_nextep_prep(self, reason=''):
		ku.set_property(PROP_NEXTEP_PREP_DECLINED, 'true')
		if reason:
			self._log_nextep('Next episode prep declined: %s' % reason)

	def _playback_meta_key(self):
		if getattr(self, 'is_generic', False):
			return None
		try:
			return '%s_%s_%s' % (self.tmdb_id, int(self.season), int(self.episode))
		except:
			return None

	def _owns_active_playback(self):
		# Key compare only — do not call isPlayingVideo() here. During seek/cache Kodi can
		# briefly report not-playing; treating that as "superseded" exits the monitor early
		# and skips progress save while the stream keeps going.
		try:
			active = ku.get_property(PROP_ACTIVE_PLAYBACK_KEY)
			mine = self._playback_meta_key()
			if not active or not mine:
				return True
			return active == mine
		except:
			return False

	def _parse_player_time_label(self, value):
		if value in (None, '', '0', '0:00', '0:00:00', 'N/A'):
			return None
		try:
			return float(value)
		except Exception:
			pass
		try:
			parts = str(value).strip().split(':')
			if len(parts) == 3:
				return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
			if len(parts) == 2:
				return int(parts[0]) * 60 + float(parts[1])
		except Exception:
			pass
		return None

	def _read_player_times(self):
		'''Live player position. Prefer Player API; fall back to InfoLabels (seek-safe).'''
		curr = total = None
		try:
			if self.isPlayingVideo():
				total = float(self.getTotalTime())
				curr = float(self.getTime())
		except Exception:
			curr = total = None
		if total in (None, 0, 0.0) or curr in (None,):
			try:
				total = self._parse_player_time_label(ku.get_infolabel('Player.Duration'))
				curr = self._parse_player_time_label(ku.get_infolabel('Player.Time'))
			except Exception:
				pass
		if (curr in (None,) or total in (None, 0, 0.0)):
			try:
				pct = ku.get_infolabel('Player.Percentage')
				if pct not in (None, '', '0', '0.0') and total not in (None, 0, 0.0):
					curr = (float(pct) / 100.0) * float(total)
				elif pct not in (None, '', '0', '0.0') and getattr(self, 'total_time', None) not in (None, 0, 0.0, ''):
					total = float(self.total_time)
					curr = (float(pct) / 100.0) * total
			except Exception:
				pass
		return curr, total

	def _refresh_playback_position(self, allow_stale=True):
		'''Update curr_time / total_time / current_point. Keep last good sample if live read fails.'''
		curr, total = self._read_player_times()
		if total not in (None, 0, 0.0) and curr not in (None,) and float(total) >= 60 and float(curr) > 0:
			# Honour forward seeks: never shrink a known larger position on a bad post-seek sample.
			prev = getattr(self, 'curr_time', None)
			try:
				prev_f = float(prev) if prev not in (None, '') else 0.0
			except Exception:
				prev_f = 0.0
			if float(curr) + 2.0 < prev_f and prev_f > 30:
				# Likely a transient 0/start sample after seek — keep previous.
				curr = prev_f
			self.total_time, self.curr_time = float(total), float(curr)
			self.current_point = round(float(self.curr_time) / float(self.total_time) * 100, 1)
			return True
		if allow_stale and getattr(self, 'total_time', None) not in (None, 0, 0.0, '') and getattr(self, 'curr_time', None) not in (None, '', 0, 0.0):
			try:
				self.current_point = round(float(self.curr_time) / float(self.total_time) * 100, 1)
				return True
			except Exception:
				pass
		return False

	def _register_active_playback(self):
		key = self._playback_meta_key()
		if key:
			ku.set_property(PROP_ACTIVE_PLAYBACK_KEY, key)

	def _release_active_playback(self):
		key = self._playback_meta_key()
		if key and ku.get_property(PROP_ACTIVE_PLAYBACK_KEY) == key:
			ku.clear_property(PROP_ACTIVE_PLAYBACK_KEY)

	def _monitor_wait(self, ms):
		# Sleep in short slices and wake as soon as playback ends, so the local progress
		# save lands before Kodi rebuilds the home widgets.
		deadline = time.time() + ms / 1000.0
		while time.time() < deadline:
			if self._playback_end_seen and not self.isPlayingVideo(): return
			ku.sleep(100)

	def _stream_stalled(self):
		'''The picture has not moved for _STALL_SEC while not paused: Kodi is stuck
		waiting on a dead connection (seen after a short Wi-Fi drop).'''
		try:
			# Live position: curr_time holds still after a rewind on purpose.
			pos = float(self.getTime())
			paused = ku.get_visibility('Player.Paused')
		except Exception:
			return False
		now = time.time()
		if paused or self._stall_pos is None or abs(pos - self._stall_pos) > 0.5:
			self._stall_pos, self._stall_since = pos, now
			return False
		return now - self._stall_since >= _STALL_SEC

	def _stop_stalled_stream(self):
		ku.logger('Red Light', 'Stream frozen for %ss at %.1fs: stopping it to reconnect' % (_STALL_SEC, self._stall_pos or 0.0))
		self._stall_detected = self._stall_stopping = True
		try: self.stop()
		except: pass
		for _ in range(50):
			if not self.isPlayingVideo(): break
			ku.sleep(100)

	def _stream_dropped(self):
		'''Playback ended mid-stream without the user stopping it: Red Light stopped a
		frozen stream, or Kodi ran out of data and ended the file well before its end.'''
		if getattr(self, 'random_continual_triggered', False): return False
		if self._stall_detected: return True
		if self._user_stopped: return False
		try: remaining = float(self.total_time) - float(self.curr_time)
		except Exception: return False
		if remaining <= _DROP_MIN_REMAINING_SEC: return False
		if not self._playback_ended:
			ku.sleep(300) # let a late Stop / End callback land
		return self._playback_ended and not self._user_stopped

	def _reconnect_dropped_stream(self):
		'''Save the spot, wait for the network, then hand back to the resolve queue: it
		plays the same source again with a fresh link, then the next sources, resuming
		just before the drop. False leaves the normal stop path to save progress.'''
		so = self.sources_object
		attempts = getattr(so, '_reconnect_attempts', 0)
		try:
			total = float(self.total_time)
			dropped_at = float(self._stall_pos if self._stall_detected and self._stall_pos else self.curr_time)
			resume_at = max(dropped_at - 10.0, 0.0)
		except Exception:
			return False
		ku.logger('Red Light', 'Stream %s at %.1fs of %.1fs (reconnect %s of %s)' % (
			'froze' if self._stall_detected else 'ended early', resume_at, total, attempts + 1, _RECONNECT_MAX))
		if attempts >= _RECONNECT_MAX:
			ku.notification('Connection lost. Progress saved', 5000)
			return False
		# Ending at the same spot again means the file itself stops there (a wrong
		# duration), not the network: replaying would loop.
		last_drop = getattr(so, '_last_drop_at', None)
		if last_drop is not None and abs(dropped_at - last_drop) < 60:
			ku.logger('Red Light', 'Stream ended at the same spot again: not reconnecting')
			return False
		so._last_drop_at = dropped_at
		if not self._wait_for_network():
			return False
		try:
			ws.set_bookmark({'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': dropped_at, 'total_time': total,
							'title': self.title, 'season': self.season, 'episode': self.episode}, remote=False)
		except Exception:
			pass
		so._reconnect_attempts = attempts + 1
		so.playback_percent = so._drop_resume_percent = round(resume_at / total * 100, 3)
		so._retry_dropped_source = True
		self.playback_successful = False
		so._resume_after_failed_start()
		self.clear_playback_properties(clear_navigation=False)
		self._release_active_playback()
		return True

	def _wait_for_network(self):
		'''True once the internet answers again; False if the user cancels, Kodi is closing,
		or it stays down for _RECONNECT_NETWORK_WAIT_SEC. Tests the internet, not the stream
		server: a dead debrid server must move on to the next source, not wait.'''
		if self._internet_up(): return True
		import xbmcgui
		dialog = xbmcgui.DialogProgress()
		dialog.create('Red Light', 'Connection lost. Waiting for the network...')
		started = time.time()
		try:
			while True:
				for _ in range(5):
					if dialog.iscanceled() or self.kodi_monitor.abortRequested():
						ku.logger('Red Light', 'Reconnect cancelled')
						return False
					ku.sleep(200)
				if self._internet_up():
					ku.logger('Red Light', 'Network back after %ds: reconnecting' % (time.time() - started))
					return True
				waited = time.time() - started
				if waited >= _RECONNECT_NETWORK_WAIT_SEC:
					ku.logger('Red Light', 'Network still down after %ds: giving up' % waited)
					ku.notification('Network still down. Progress saved', 5000)
					return False
				dialog.update(int(waited * 100 / _RECONNECT_NETWORK_WAIT_SEC))
		finally:
			try: dialog.close()
			except: pass

	def _internet_up(self):
		# A name lookup plus a connection: the 12:30 drop failed at the lookup.
		import socket
		for host in ('www.google.com', 'www.cloudflare.com'):
			try:
				socket.create_connection((host, 443), timeout=3).close()
				return True
			except Exception:
				pass
		return False

	def _should_prep_next_ep(self):
		if not self._owns_active_playback():
			return False
		if getattr(self, '_nextep_stash_play_scheduled', False):
			return False
		if ku.get_property(PROP_NEXTEP_PREP_DECLINED) == 'true':
			return False
		if getattr(self, '_nextep_prep_attempted', False):
			return False
		if ku.get_property(PROP_NEXTEP_AUTOPLAY_CANCELLED) == 'true':
			return False
		if ku.get_property(PROP_NEXTEP_PENDING) == 'true':
			return False
		if ku.get_property(PROP_NEXTEP_PREP_SCHEDULED) == 'true':
			return False
		if self.autoplay_nextep and ku.get_property('redlight.nextep_scrape_ready') == 'true':
			try:
				from modules.sources import peek_nextep_autoplay_stash
				if peek_nextep_autoplay_stash():
					return False
			except:
				pass
		if not self._valid_playback_duration(self.total_time, self.curr_time):
			return False
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return False
		return remaining > 0 and remaining <= self.start_prep

	def _nextep_play_type(self):
		return 'autoplay_nextep' if self.autoplay_nextep else 'autoscrape_nextep'

	def _still_watching_due(self, nextep_settings):
		watching_check = nextep_settings.get('watching_check', 0)
		return watching_check and self.meta_get('watch_count') == watching_check

	def _pop_window_seconds(self, nextep_settings, total_time):
		return self._alert_window_time(nextep_settings, 90, total_time, still_watching_check=0)

	def _start_prep_seconds(self, nextep_settings, pop_at, play_type, include_still_watching=True):
		still_watching_due = self._still_watching_due(nextep_settings) if include_still_watching else False
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], still_watching_due)
		return int(pop_at) + pipeline

	def _resolve_subtitle_pop_at(self, sub_tail, credits_entry):
		# subtitles.py returns the target remaining seconds; do not clamp to NEXTEP_ALERT_MAX (that cap is for % fallback only).
		vals = [int(v) for v in (sub_tail, credits_entry) if v is not None]
		if not vals: return None
		return max(max(vals), st.NEXTEP_ALERT_MIN_REMAINING_SEC)

	def _subtitle_credits_entry_remaining(self, fetch=False, quiet=False):
		if getattr(self, 'is_generic', False) or not getattr(self, 'imdb_id', None): return None
		if quiet:
			cached = getattr(self, '_subtitle_credits_entry_cached', '__unset__')
			if cached != '__unset__': return cached
		try:
			from indexers.subtitles import subtitle_seconds_remaining_before_end
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			remaining = subtitle_seconds_remaining_before_end(float(self.total_time), self.imdb_id, season, episode, fetch=fetch,
				player=self, playing_filename=getattr(self, 'playing_filename', None), playing_item=getattr(self, 'playing_item', None),
				playback_started_at=getattr(self, '_playback_started_at', None),
				year=getattr(self, 'year', None), credits_entry=True, quiet=quiet)
		except:
			remaining = None
		if quiet: self._subtitle_credits_entry_cached = remaining
		return remaining

	def _ensure_random_continual_prep(self):
		if getattr(self, 'random_continual_start_prep', None) is not None: return
		if st.autoscrape_next_episode(): play_type = 'autoscrape_nextep'
		elif st.autoplay_next_episode(): play_type = 'autoplay_nextep'
		else: play_type = 'autoscrape_nextep'
		nextep_settings = st.auto_nextep_settings(play_type)
		pop_at, _timing_source = self._pop_window_seconds(nextep_settings, self.total_time)
		# Headroom for Still Watching when Check Still Watching After X is enabled (Continual Random).
		include_still_watching = bool(nextep_settings.get('watching_check', 0))
		self.random_continual_start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type, include_still_watching)

	def _should_prep_random_continual(self):
		if getattr(self, 'random_continual_triggered', False): return False
		if not self._valid_playback_duration(self.total_time, self.curr_time): return False
		self._ensure_random_continual_prep()
		try: remaining = round(float(self.total_time) - float(self.curr_time))
		except: return False
		return remaining > 0 and remaining <= self.random_continual_start_prep

	def _schedule_next_ep(self):
		if ku.get_property(PROP_NEXTEP_PENDING) == 'true':
			return
		if ku.get_property(PROP_NEXTEP_PREP_SCHEDULED) == 'true':
			return
		try: remaining = round(float(self.total_time) - float(self.curr_time))
		except: remaining = -1
		self._log_nextep('Next episode prep scheduled: %s S%02dE%02d play_type=%s remaining=%ss start_prep=%ss' % (
			self.meta_get('title', ''), self.meta_get('season', 0), self.meta_get('episode', 0),
			self.nextep_settings.get('play_type', ''), remaining, getattr(self, 'start_prep', '')))
		self._nextep_prep_attempted = True
		ku.set_property(PROP_NEXTEP_PREP_SCHEDULED, 'true')
		ku.set_property(PROP_NEXTEP_PENDING, 'true')
		meta = dict(self.meta) if getattr(self, 'meta', None) else {}
		nextep_settings = dict(self.nextep_settings) if getattr(self, 'nextep_settings', None) else None
		def _work():
			try:
				from modules.episode_tools import EpisodeTools
				if not self.media_marked:
					try: self.media_watched_marker(force_watched=True)
					except: pass
				EpisodeTools(meta, nextep_settings).auto_nextep()
			except Exception as exc:
				ku.logger('Red Light', 'Next episode prep failed: %s' % exc)
			finally:
				ku.clear_property(PROP_NEXTEP_PENDING)
				ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
		Thread(target=_work, daemon=True).start()

	def _maybe_log_nextep_alert_pending(self):
		if not self.autoplay_nextep or getattr(self, '_nextep_alert_shown', False): return
		if not self._owns_active_playback(): return
		if getattr(self, '_nextep_alert_pending_logged', False): return
		if ku.get_property('redlight.nextep_scrape_ready') != 'true': return
		try:
			from modules.sources import peek_nextep_autoplay_stash
			if not peek_nextep_autoplay_stash(): return
		except:
			return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		window = int(getattr(self, 'nextep_settings', {}).get('window_time', 0) or 0)
		if remaining <= 0 or remaining <= window: return
		self._nextep_alert_pending_logged = True
		self._log_nextep('Autoplay next episode alert pending: remaining=%ss window=%ss (scrape ready)' % (remaining, window))

	def _should_show_autoplay_nextep_alert(self):
		if not self.autoplay_nextep or not getattr(self, 'nextep_settings', None): return False
		if getattr(self, '_nextep_alert_shown', False): return False
		if not self._owns_active_playback():
			return False
		try:
			from modules.sources import nextep_autoplay_cancelled, peek_nextep_autoplay_stash, nextep_alert_handled, PROP_NEXTEP_SCRAPE_KEY
			if nextep_autoplay_cancelled(): return False
			key = ku.get_property(PROP_NEXTEP_SCRAPE_KEY)
			if nextep_alert_handled(key):
				self._nextep_alert_shown = True
				return False
		except:
			pass
		if ku.get_property('redlight.nextep_scrape_ready') != 'true': return False
		try:
			from modules.sources import peek_nextep_autoplay_stash
			if not peek_nextep_autoplay_stash(): return False
		except:
			return False
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return False
		window = int(self.nextep_settings.get('window_time', 0) or 0)
		return remaining > 0 and remaining <= window

	def _try_autoscrape_nextep_ready_notify(self):
		if not self.autoscrape_nextep or getattr(self, '_autoscrape_ready_notified', False): return
		if not self._owns_active_playback(): return
		if not ku.get_property(PROP_AUTOSCRAPE_NEXTEP_READY): return
		if not getattr(self, 'nextep_settings', None): return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		window = int(self.nextep_settings.get('window_time', 0) or 0)
		if remaining <= 0 or remaining > window: return
		self._autoscrape_ready_notified = True
		meta = {}
		try:
			raw = ku.get_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			if raw and raw != 'true':
				meta = json.loads(raw)
		except:
			pass
		ku.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
		ku.set_property(ku.PROP_AUTOSCRAPE_TOAST_SHOWN, 'true')
		title = meta.get('title') or self.meta_get('title', '')
		season = meta.get('season', self.season)
		episode = meta.get('episode', self.episode)
		poster = meta.get('poster') or self.meta_get('poster')
		ku.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' % (title, season, episode), 6500, poster)
		try:
			from modules.sources import arm_nextep_handoff_cover
			arm_nextep_handoff_cover()
		except Exception:
			pass
		self._log_nextep('Autoscrape next episode ready notify: remaining=%ss window=%ss' % (remaining, window))

	def _try_autoplay_early_stash_play(self):
		if not self.autoplay_nextep or not getattr(self, '_nextep_close_wait', False):
			return
		if not self._owns_active_playback():
			return
		if getattr(self, '_nextep_stash_play_scheduled', False) or not getattr(self, '_nextep_alert_shown', False):
			return
		try:
			from modules.sources import nextep_autoplay_cancelled, nextep_end_play_superseded, peek_nextep_autoplay_stash, schedule_nextep_stashed_play, take_nextep_autoplay_stash
			if nextep_autoplay_cancelled() or nextep_end_play_superseded() or not peek_nextep_autoplay_stash():
				return
		except:
			return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		if remaining > _NEXTEP_CLOSE_EARLY_PLAY_SEC or remaining <= 0:
			return
		stash = take_nextep_autoplay_stash()
		if not stash:
			return
		if schedule_nextep_stashed_play(stash, show_busy=False):
			self._nextep_stash_play_scheduled = True
			self._log_nextep('Autoplay next episode: early stash resolve at remaining=%ss' % remaining)

	def _try_autoplay_nextep_alert(self):
		if not self._should_show_autoplay_nextep_alert(): return
		try:
			from modules.sources import peek_nextep_autoplay_stash, take_nextep_autoplay_stash, claim_nextep_alert_handled, PROP_NEXTEP_SCRAPE_KEY
		except:
			return
		stash_key = ku.get_property(PROP_NEXTEP_SCRAPE_KEY)
		if not claim_nextep_alert_handled(stash_key):
			self._nextep_alert_shown = True
			return
		self._nextep_alert_shown = True
		stash = peek_nextep_autoplay_stash()
		if not stash: return
		settings = self.nextep_settings
		# Play # Episodes: silent chain — wait for natural end, then play stashed next.
		if settings.get('play_n_episodes'):
			self._nextep_close_wait = True
			self._log_nextep('Play # Episodes: silent continue (remaining after this=%s)' % settings.get('num_episodes'))
			return
		use_window = settings.get('use_window')
		default_action = settings.get('default_action')
		dialog_meta = stash['meta']
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			remaining = settings.get('window_time')
		self._log_nextep('Autoplay next episode alert: remaining=%ss window=%ss method=%s' % (
			remaining, settings.get('window_time'), 'window' if use_window else 'notification'))
		action = None
		if use_window:
			from windows.base_window import open_window
			try:
				action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml', meta=dialog_meta, default_action=default_action)
			except:
				action = 'cancel'
		else:
			ku.notification('[B]Next Up:[/B] %s S%02dE%02d' % (dialog_meta.get('title'), dialog_meta.get('season'), dialog_meta.get('episode')), 6500, dialog_meta.get('poster'))
		if not action:
			action = default_action if use_window else 'close'
		if not action:
			action = 'close'
		if action == 'cancel':
			try:
				from modules.sources import mark_nextep_autoplay_cancelled
				mark_nextep_autoplay_cancelled()
			except:
				pass
			ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
			self._log_nextep('Autoplay next episode alert action: cancel')
			return
		if action == 'pause':
			self._nextep_close_wait = True
			self._log_nextep('Autoplay next episode alert action: pause (waiting for user)')
			return
		if action == 'close':
			self._nextep_close_wait = True
			self._log_nextep('Autoplay next episode alert action: close (waiting for episode end)')
			return
		if action != 'play':
			return
		self._log_nextep('Autoplay next episode alert action: play')
		stash = take_nextep_autoplay_stash()
		if not stash: return
		try:
			from modules.sources import schedule_nextep_stashed_play
			if schedule_nextep_stashed_play(stash):
				self._nextep_stash_play_scheduled = True
			else:
				ku.logger('Red Light', 'Autoplay next episode play failed: could not schedule resolve')
		except Exception as exc:
			ku.logger('Red Light', 'Autoplay next episode play failed: %s' % exc)
		return

	def run_next_ep(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta, self.nextep_settings).auto_nextep()

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def run_movie_stingers(self):
		self.movie_stingers_run = True
		stinger_keys = self.meta.get('stinger_keys', None)
		if not stinger_keys:
			try:
				keywords = self.meta.get('keywords', [])
				stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
				self.meta['stinger_keys'] = stinger_keys
			except: pass
		if stinger_keys:
			from windows.base_window import open_window
			Thread(target=lambda: open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=self.meta)).start()

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def _nextep_aio_en_fresh_start(self):
		try:
			sources = self.sources_object
			if not sources or not getattr(sources, '_nextep_aio_en_fresh_start', None):
				return False
			return sources._nextep_aio_en_fresh_start(getattr(self, 'playing_item', None))
		except:
			return False

	def _disable_kodi_url_resume(self, listitem, keep_start_percent=False):
		# Kodi stores resume by stream URL/filename; debrid links reuse the same name and can reopen near EOF.
		if not keep_start_percent or float(listitem.getProperty('StartPercent') or 0) <= 0:
			listitem.setProperty('StartPercent', '0')
		listitem.setProperty('StartOffset', '0')
		try:
			listitem.getVideoInfoTag(True).setResumePoint(0.0)
		except:
			pass

	def info_next_ep(self):
		self.nextep_info_gathered = True
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		pop_at, timing_source = self._pop_window_seconds(nextep_settings, self.total_time)
		credits_entry = self._subtitle_credits_entry_remaining(fetch=False) if nextep_settings.get('alert_timing') == 'subtitles' else None
		use_window = nextep_settings['alert_method'] == 0
		default_action = nextep_settings['default_action']
		# Play # Episodes: no Still Watching budget; headroom without that dialog.
		play_n_active = False
		try: play_n_remaining = int(self.num_episodes) if getattr(self, 'num_episodes', None) not in (None, '') else 0
		except: play_n_remaining = 0
		if play_n_remaining > 1:
			play_n_active = True
			use_window = False
			default_action = 'close'
		still_watching_due = False if play_n_active else self._still_watching_due(nextep_settings)
		self.start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type, include_still_watching=not play_n_active)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], still_watching_due)
		self.nextep_settings = {'use_window': use_window, 'window_time': pop_at, 'default_action': default_action, 'play_type': play_type,
			'alert_timing': nextep_settings.get('alert_timing'),
			'watching_check': 0 if play_n_active else nextep_settings['watching_check'],
			'pipeline_headroom': pipeline, 'credits_entry': credits_entry}
		if play_n_active:
			# Count for the *next* episode includes that episode; stop when it reaches 1.
			self.nextep_settings['num_episodes'] = str(play_n_remaining - 1)
			self.nextep_settings['play_n_episodes'] = True
		if nextep_settings.get('alert_timing') == 'introdb':
			outro_start = self._outro_credits_start(fetch=True)
			if outro_start is not None:
				self.nextep_settings['outro_start'] = outro_start
		credits_log = ' credits_entry=%ss' % credits_entry if credits_entry is not None else ''
		outro_start = self.nextep_settings.get('outro_start')
		outro_log = ' outro_start=%.1fs' % outro_start if outro_start is not None else ''
		play_n_log = ' play_n=%s' % play_n_remaining if play_n_remaining else ''
		self._log_nextep('Next episode timing: play_type=%s alert=%s source=%s pop_at=%ss pipeline=%ss start_prep=%ss total=%ss%s%s%s' % (
			play_type, nextep_settings.get('alert_timing'), timing_source, pop_at, pipeline, self.start_prep, round(float(self.total_time)), credits_log, outro_log, play_n_log))

	def final_chapter(self, threshhold):
		try:
			final_chapter = float(ku.get_infolabel('Player.Chapters').split(',')[-1])
			if final_chapter >= threshhold: return final_chapter
		except: pass
		return None

	def _clear_subtitle_end_cache(self):
		self._subtitle_end_remaining_cached = '__unset__'
		self._subtitle_credits_entry_cached = '__unset__'

	def _subtitle_alert_fetch_pending(self):
		return getattr(self, '_subtitle_alert_fetch_started', False) and not getattr(self, '_subtitle_alert_fetch_done', False)

	def _maybe_start_introdb_alert_fetch(self):
		if getattr(self, '_introdb_alert_fetch_started', False): return
		if self.is_generic or self.media_type != 'episode': return
		if not (self.autoplay_nextep or self.autoscrape_nextep): return
		nextep_settings = st.auto_nextep_settings(self._nextep_play_type())
		if nextep_settings.get('alert_timing') != 'introdb': return
		self._introdb_alert_fetch_started = True
		season = self.season
		episode = self.episode
		tmdb_id, imdb_id = self.tmdb_id, self.imdb_id
		def _work():
			try:
				from apis.intro_skip_api import prefetch_credits_start
				duration = None
				try: duration = float(self.total_time) if self.total_time else None
				except: pass
				prefetch_credits_start(tmdb_id, imdb_id, season, episode, duration)
			except: pass
			finally:
				self._outro_credits_start_cached = '__unset__'
		Thread(target=_work, daemon=True).start()

	def _maybe_start_subtitle_alert_fetch(self):
		if getattr(self, '_subtitle_alert_fetch_started', False): return
		if self.is_generic or not self.imdb_id: return
		if not st.subs_alert_fetch_enabled(self.media_type): return
		self._subtitle_alert_fetch_started = True
		season = self.season if self.media_type == 'episode' else None
		episode = self.episode if self.media_type == 'episode' else None
		year = getattr(self, 'year', None)
		playing_filename = getattr(self, 'playing_filename', None)
		playing_item = getattr(self, 'playing_item', None)
		def _work():
			try:
				from indexers.subtitles import fetch_subtitle_for_alert_timing
				fetch_subtitle_for_alert_timing(self.imdb_id, season, episode, year, playing_filename, playing_item)
			except: pass
			finally:
				self._subtitle_alert_fetch_done = True
				self._clear_subtitle_end_cache()
		Thread(target=_work, daemon=True).start()

	def _subtitle_end_remaining(self, fetch=False, for_alert=False):
		cached = getattr(self, '_subtitle_end_remaining_cached', '__unset__')
		cache_key = 'alert' if for_alert else 'scrape'
		cached_by_mode = cached if isinstance(cached, dict) else {}
		if cache_key in cached_by_mode and (cached_by_mode[cache_key] is not None or getattr(self, 'subs_searched', False)) and not self._subtitle_alert_fetch_pending():
			return cached_by_mode[cache_key]
		try:
			from indexers.subtitles import subtitle_seconds_remaining_before_end
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			remaining = subtitle_seconds_remaining_before_end(float(self.total_time), self.imdb_id, season, episode, fetch=fetch,
				player=self, playing_filename=getattr(self, 'playing_filename', None), playing_item=getattr(self, 'playing_item', None),
				playback_started_at=getattr(self, '_playback_started_at', None),
				year=getattr(self, 'year', None), for_alert=for_alert)
		except:
			remaining = None
		if remaining is not None:
			cached_by_mode[cache_key] = remaining
			self._subtitle_end_remaining_cached = cached_by_mode
		elif getattr(self, 'subs_searched', False):
			cached_by_mode[cache_key] = None
			self._subtitle_end_remaining_cached = cached_by_mode
		return remaining

	def _alert_window_time(self, nextep_settings, chapter_threshold, total_time, still_watching_check=0):
		alert_timing = nextep_settings.get('alert_timing', 'off')
		window_percentage = nextep_settings['window_percentage']
		try: total_time = float(total_time)
		except:
			return window_percentage + still_watching_check, 'percentage'
		if alert_timing == 'chapters':
			final_chapter = self.final_chapter(chapter_threshold)
			if final_chapter:
				percentage = 100 - final_chapter
				return round((percentage / 100) * total_time) + still_watching_check, 'chapters'
		if alert_timing == 'subtitles':
			sub_remaining = self._subtitle_end_remaining(fetch=True, for_alert=True)
			credits_entry = self._subtitle_credits_entry_remaining(fetch=False, quiet=True)
			pop_at = self._resolve_subtitle_pop_at(sub_remaining, credits_entry)
			if pop_at is not None:
				return pop_at + still_watching_check, 'subtitles'
		if alert_timing == 'introdb':
			pop_at = self._outro_credits_pop_at(fetch=True)
			if pop_at is not None:
				return pop_at + still_watching_check, 'introdb'
		fallback = 'percentage_fallback' if alert_timing in ('chapters', 'subtitles', 'introdb') else 'percentage'
		pop_at = round((window_percentage / 100) * total_time) + still_watching_check
		if alert_timing == 'subtitles':
			pop_at = min(int(pop_at), st.NEXTEP_ALERT_MAX_REMAINING_SEC)
		return pop_at, fallback

	def _maybe_refresh_nextep_subtitle_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'subtitles': return
		sub_alert = self._subtitle_end_remaining(fetch=False, for_alert=True)
		if sub_alert is None: return
		credits_entry = self._subtitle_credits_entry_remaining(fetch=False, quiet=True)
		pop_at = self._resolve_subtitle_pop_at(sub_alert, credits_entry)
		if pop_at is None: return
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep and credits_entry == self.nextep_settings.get('credits_entry'): return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self.nextep_settings['credits_entry'] = credits_entry
		credits_log = ' credits_entry=%ss' % credits_entry if credits_entry is not None else ''
		self._log_nextep('Next episode timing refreshed (subtitles): pop_at=%ss start_prep=%ss%s' % (pop_at, start_prep, credits_log))

	def _maybe_refresh_nextep_chapter_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'chapters': return
		if not self.final_chapter(90): return
		pop_at, _timing_source = self._alert_window_time(nextep_settings, 90, self.total_time, still_watching_check=0)
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep: return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self._log_nextep('Next episode timing refreshed (chapters): pop_at=%ss start_prep=%ss' % (pop_at, start_prep))

	def _outro_credits_start(self, fetch=False):
		if getattr(self, 'is_generic', False) or self.media_type != 'episode':
			return None
		cache_attr = '_outro_credits_start_cached'
		if not fetch:
			cached = getattr(self, cache_attr, '__unset__')
			if cached != '__unset__':
				return cached
		try:
			from apis.intro_skip_api import resolve_credits_start_sec
			duration = float(self.total_time) if self.total_time else None
			start_sec = resolve_credits_start_sec(self.tmdb_id, self.imdb_id, self.season, self.episode, duration)
		except:
			start_sec = None
		setattr(self, cache_attr, start_sec)
		return start_sec

	def _outro_credits_pop_at(self, fetch=False):
		try:
			total_time = float(self.total_time)
		except:
			return None
		start_sec = self._outro_credits_start(fetch=fetch)
		if start_sec is None:
			return None
		pop_at = int(round(total_time - float(start_sec) + st.NEXTEP_INTRODB_BUFFER_SEC))
		return max(pop_at, st.NEXTEP_ALERT_MIN_REMAINING_SEC)

	def _maybe_refresh_nextep_introdb_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'introdb': return
		pop_at = self._outro_credits_pop_at(fetch=False)
		if pop_at is None: return
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		outro_start = getattr(self, '_outro_credits_start_cached', None)
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep and outro_start == self.nextep_settings.get('outro_start'): return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self.nextep_settings['outro_start'] = outro_start
		outro_log = ' outro_start=%.1fs' % outro_start if outro_start is not None else ''
		self._log_nextep('Next episode timing refreshed (introdb): pop_at=%ss start_prep=%ss%s' % (pop_at, start_prep, outro_log))

	def _stinger_early_percentage(self, trigger_pct):
		try:
			total = float(self.total_time)
			if total > 0:
				trigger_pct = round(trigger_pct - (_STINGER_EARLY_OFFSET_SEC / total * 100), 1)
				return max(1.0, trigger_pct)
		except: pass
		return trigger_pct

	def _stinger_trigger_point(self, alert_timing, fallback_percentage):
		if alert_timing == 'chapters':
			trigger_pct = self.final_chapter(75) or fallback_percentage
		elif alert_timing == 'subtitles':
			trigger_pct = fallback_percentage
			try:
				sub_remaining = self._subtitle_end_remaining(fetch=True, for_alert=True)
				if sub_remaining is not None and self.total_time:
					trigger_pct = round(100 - (float(sub_remaining) / float(self.total_time) * 100), 1)
			except: pass
		else:
			trigger_pct = fallback_percentage
		return self._stinger_early_percentage(trigger_pct)

	def kill_dialog(self):
		try:
			self.sources_object._kill_progress_dialog()
		except:
			if not getattr(self.sources_object, '_resolve_user_cancelled', False):
				ku.close_all_dialog()

	def set_constants(self, url, obj):
		self.url = url
		self.sources_object = obj
		self.is_generic = self.sources_object == 'video'
		self.kodi_monitor = ku.kodi_monitor()
		self.playback_successful = None
		self.cancel_all_playback = False
		if not self.is_generic:
			self.meta = self.sources_object.meta
			self.meta_get, self.playback_percent = self.meta.get, self.sources_object.playback_percent or 0.0
			self.playing_filename = self.sources_object.playing_filename
			self.media_marked, self.nextep_info_gathered, self.movie_stingers_run = False, False, False
			self.watched_tick_percent = st.playback_watched_percent()
			self.current_point = 0
			self.subs_searched = False
			self._subtitle_end_remaining_cached = '__unset__'
			self._subtitle_alert_fetch_started = False
			self._subtitle_alert_fetch_done = False
			self._playback_started_at = time.time()
			self._nextep_prep_attempted = False
			ku.clear_property(PROP_NEXTEP_PENDING)
			ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
			ku.clear_property(PROP_NEXTEP_PREP_DECLINED)
			ku.clear_property(PROP_NEXTEP_NATURAL_END)
			ku.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			ku.clear_property(PROP_NEXTEP_AUTOPLAY_CANCELLED)
			ku.clear_property(PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS)
			ku.clear_property(ku.PROP_AUTOSCRAPE_TOAST_SHOWN)
			self._autoscrape_ready_notified = False
			self._nextep_alert_pending_logged = False
			self._nextep_close_wait = False
			self._nextep_stash_play_scheduled = False
			self.playing_item = self.sources_object.playing_item
			self._intro_skip_active = False
			self._intro_skip_done = False
			self._intro_skip_segment = None
			self._intro_skip_no_timing_logged = False
			self._intro_skip_last_curr = None
			self._intro_skip_settle_ready = False
			self._outro_credits_start_cached = '__unset__'

	def _start_intro_skip_fetch(self):
		play_type = getattr(self.sources_object, 'play_type', '')
		if self.media_type != 'episode':
			return
		if not st.autoplay_skip_intro_enabled(play_type):
			self._log_intro_skip('Intro skip: disabled (mode=%s all_episodes=%s)' % (
				st.skip_intro_mode(), st.skip_intro_all_episodes()))
			return
		self._intro_skip_active = True
		self._intro_skip_done = False
		self._intro_skip_prompt_answered = False
		self._intro_skip_approved = st.autoplay_skip_intro_auto(play_type)
		self._intro_skip_fetch_done = False
		self._intro_skip_no_timing_logged = False
		try:
			from apis.intro_skip_api import peek_intro_segment_cache
			duration = None
			try:
				total = getattr(self, 'total_time', None)
				if total not in (None, '', 0, 0.0): duration = float(total)
			except: pass
			cached = peek_intro_segment_cache(self.tmdb_id, self.imdb_id, self.season, self.episode, duration)
			if cached != '__miss__':
				self._intro_skip_fetch_done = True
				if cached:
					self._intro_skip_segment = cached
				return
		except: pass
		def _work():
			try:
				from apis.intro_skip_api import resolve_intro_segment
				total = getattr(self, 'total_time', None)
				duration = None
				try:
					if total not in (None, '', 0, 0.0): duration = float(total)
				except: pass
				segment = resolve_intro_segment(self.tmdb_id, self.imdb_id, self.season, self.episode, duration)
				if segment and not getattr(self, '_intro_skip_segment', None):
					self._intro_skip_segment = segment
			except: pass
			finally:
				self._intro_skip_fetch_done = True
		Thread(target=_work, daemon=True).start()

	def _try_intro_skip_chapters(self):
		if getattr(self, '_intro_skip_segment', None):
			return
		if not getattr(self, '_intro_skip_fetch_done', False):
			return
		try:
			total = float(self.total_time)
			if total < 60:
				return
			raw = ku.get_infolabel('Player.Chapters')
			if not raw:
				return
			marks = [float(x) for x in raw.split(',') if x.strip()]
			if len(marks) < 2:
				return
			start_pct, end_pct = marks[0], marks[1]
			if start_pct > 5 or end_pct > 30 or end_pct <= start_pct:
				return
			start_sec = total * start_pct / 100.0
			end_sec = total * end_pct / 100.0
			if end_sec - start_sec < _INTRO_CHAPTER_MIN_SEGMENT_SEC or end_sec < _INTRO_CHAPTER_MIN_END_SEC:
				return
			self._intro_skip_segment = {'start_sec': start_sec, 'end_sec': end_sec, 'source': 'chapters'}
		except: pass

	def _maybe_log_intro_skip_no_timing(self):
		if getattr(self, '_intro_skip_no_timing_logged', False):
			return
		if not getattr(self, '_intro_skip_fetch_done', False):
			return
		if getattr(self, '_intro_skip_segment', None):
			return
		self._try_intro_skip_chapters()
		if getattr(self, '_intro_skip_segment', None):
			return
		self._intro_skip_no_timing_logged = True
		self._intro_skip_done = True
		self._log_intro_skip('Intro skip: no timing (api miss, chapters rejected)')

	def _intro_resume_sec(self):
		if self.playback_percent and float(self.playback_percent) > 0:
			try: return float(self.total_time) * float(self.playback_percent) / 100.0
			except: pass
		return None

	def _intro_effective_playhead(self):
		try: curr = float(self.curr_time)
		except: curr = 0.0
		resume_sec = self._intro_resume_sec()
		if resume_sec is not None: return max(curr, resume_sec)
		return curr

	def _intro_skip_position_settled(self):
		if getattr(self, '_intro_skip_settle_ready', False): return True
		started = getattr(self, '_playback_started_at', None)
		if not started: return True
		elapsed = time.time() - started
		try: curr = float(self.curr_time)
		except: return False
		last = getattr(self, '_intro_skip_last_curr', None)
		if last is not None and abs(curr - last) >= _INTRO_SKIP_SETTLE_JUMP_SEC:
			self._intro_skip_last_curr = curr
			return False
		resume_sec = self._intro_resume_sec()
		if resume_sec is not None and resume_sec > _INTRO_SKIP_PROMPT_EARLY_SEC:
			self._intro_skip_settle_ready = True
			return True
		if elapsed < _INTRO_SKIP_SETTLE_SEC:
			self._intro_skip_last_curr = curr
			return False
		if last is not None and abs(curr - last) <= 3:
			self._intro_skip_settle_ready = True
			return True
		if elapsed >= _INTRO_SKIP_SETTLE_MAX_WAIT_SEC:
			self._intro_skip_settle_ready = True
			return True
		self._intro_skip_last_curr = curr
		return False

	def _intro_skip_past_segment(self, segment):
		try:
			end_sec = float(segment['end_sec'])
			curr = self._intro_effective_playhead()
			if getattr(self, '_intro_skip_approved', False) and curr < end_sec + _INTRO_SKIP_POST_END_GRACE_SEC:
				return False
			if curr >= end_sec:
				return True
		except: pass
		return False

	def _restore_fullscreen_after_intro_skip(self):
		try:
			from windows.playback_notifications import _restore_fullscreen_playback
			_restore_fullscreen_playback(self)
		except Exception:
			pass

	def _execute_intro_skip_seek(self, start_sec, end_sec, source):
		# One seek only — a 400ms getTime() check often still shows the old
		# playhead, so the old retry fired a second seekTime while the first
		# was in flight (Amlogic / CoreELEC decoder panic, #220).
		if not self._player_is_active():
			self._log_intro_skip('Intro skip failed: player inactive')
			return False
		ok = self.seek(end_sec, False)
		# No-op if the prompt already restored fullscreen. Do not re-assert
		# during an in-flight seek (that hitch was the post-Yes freeze).
		self._restore_fullscreen_after_intro_skip()
		if not ok:
			self._log_intro_skip('Intro skip failed: seek rejected')
			return False
		self._log_intro_skip('Intro skip (%s): %.1fs -> %.1fs' % (source, start_sec, end_sec))
		return True

	def _prompt_intro_skip(self):
		if not self._player_is_active():
			return False
		try:
			try:
				curr = float(self.curr_time)
				seg = getattr(self, '_intro_skip_segment', None) or {}
				self._log_intro_skip('Intro skip: opening prompt at %.1fs (segment %.1fs-%.1fs)' % (
					curr, float(seg.get('start_sec', 0) or 0), float(seg.get('end_sec', 0) or 0)))
			except: pass
			from windows.base_window import open_window
			return open_window(('windows.playback_notifications', 'IntroSkipPrompt'), 'playback_notifications.xml',
				meta=self.meta, countdown_sec=_INTRO_SKIP_PROMPT_COUNTDOWN_SEC)
		except:
			return False

	def _maybe_apply_intro_skip(self):
		if not getattr(self, '_intro_skip_active', False) or getattr(self, '_intro_skip_done', False):
			return
		if not self._player_is_active():
			return
		self._try_intro_skip_chapters()
		segment = getattr(self, '_intro_skip_segment', None)
		if not segment:
			self._maybe_log_intro_skip_no_timing()
			return
		if self._intro_skip_past_segment(segment):
			if getattr(self, '_intro_skip_approved', False):
				self._log_intro_skip('Intro skip missed: past grace window')
			else:
				self._log_intro_skip('Intro skip: past intro (prompt not shown)')
			self._intro_skip_done = True
			return
		try:
			start_sec = float(segment['start_sec'])
			end_sec = float(segment['end_sec'])
			curr = float(self.curr_time)
		except:
			return
		if not getattr(self, '_intro_skip_prompt_answered', False) and st.skip_intro_needs_prompt(getattr(self.sources_object, 'play_type', '')):
			if not self._intro_skip_position_settled():
				return
			effective_curr = self._intro_effective_playhead()
			should_prompt = (start_sec <= _INTRO_SKIP_EARLY_START_SEC and effective_curr <= _INTRO_SKIP_PROMPT_EARLY_SEC) or (effective_curr >= start_sec and effective_curr < end_sec)
			if should_prompt:
				choice = self._prompt_intro_skip()
				self._intro_skip_prompt_answered = True
				if choice is None:
					self._intro_skip_done = True
					self._log_intro_skip('Intro skip: timed out')
					return
				if not choice:
					self._intro_skip_done = True
					self._log_intro_skip('Intro skip: declined')
					return
				self._intro_skip_approved = True
				ku.sleep(_INTRO_SKIP_SEEK_SETTLE_MS)
				try:
					curr = float(self.curr_time)
				except:
					return
		if not getattr(self, '_intro_skip_approved', False):
			return
		if self._intro_skip_past_segment(segment):
			self._log_intro_skip('Intro skip missed: past grace window')
			self._intro_skip_done = True
			return
		if curr < start_sec:
			return
		if curr >= end_sec:
			self._intro_skip_done = True
			self._log_intro_skip('Intro skip: already past intro (%.1fs >= %.1fs)' % (curr, end_sec))
			return
		try:
			if self._execute_intro_skip_seek(start_sec, end_sec, segment.get('source', '?')):
				self._intro_skip_done = True
		except Exception as exc:
			self._log_intro_skip('Intro skip failed: %s' % exc)
			self._intro_skip_done = True

	def run_subtitles(self):
		self.subs_searched = True
		self._clear_subtitle_end_cache()
		if not st.auto_enable_subs(): return
		if not self.imdb_id: return
		try:
			from indexers.subtitles import subtitle_notify_poster
			poster = subtitle_notify_poster(self.meta, self.media_type)
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			year = getattr(self, 'year', None)
			playing_filename = getattr(self, 'playing_filename', None)
			playing_item = getattr(self, 'playing_item', None)
			if st.submaker_enabled():
				from indexers.subtitles import Subtitles
				Thread(target=Subtitles().run, args=(self.imdb_id, season, episode, poster, playing_filename, playing_item, self, year)).start()
			elif st.opensubs_enabled():
				from indexers.subtitles import OpenSubtitlesSubs
				Thread(target=OpenSubtitlesSubs().run, args=(self.imdb_id, season, episode, poster, year, playing_filename, playing_item, self)).start()
		except: pass

	def set_playback_properties(self):
		try:
			trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id, 'slug': make_trakt_slug(self.title)}
			if self.media_type == 'episode': trakt_ids['tvdb'] = self.tvdb_id
			ku.set_property('script.trakt.ids', json.dumps(trakt_ids))
			if self.playing_filename or getattr(self, 'playing_item', None):
				try:
					from indexers.subtitles import _best_play_filename
					season = self.season if self.media_type == 'episode' else None
					episode = self.episode if self.media_type == 'episode' else None
					best = _best_play_filename(self.playing_filename, getattr(self, 'playing_item', None), season, episode)
					ku.set_property('subs.player_filename', best or self.playing_filename)
				except:
					if self.playing_filename: ku.set_property('subs.player_filename', self.playing_filename)
			elif self.playing_filename:
				ku.set_property('subs.player_filename', self.playing_filename)
		except: pass

	def safe_stop(self):
		try:
			opening = ku.get_property(PROP_PLAY_OPENING) == 'true'
			if opening and not self.isPlayingVideo() and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.execute_builtin('PlayerControl(Stop)', block=False)
				return
			if self.isPlayingVideo() or ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				if self.isPlaying():
					self.stop()
				ku.sleep(150)
			elif self.isPlaying():
				ku.execute_builtin('PlayerControl(Stop)', block=False)
				ku.sleep(100)
		except:
			pass
		finally:
			ku.clear_property(PROP_PLAY_OPENING)

	def clear_playback_properties(self, clear_navigation=True):
		if clear_navigation:
			ku.clear_property('redlight.window_stack')
		ku.clear_property('script.trakt.ids')
		ku.clear_property('subs.player_filename')
		try:
			from indexers.subtitles import clear_active_subtitle_path
			clear_active_subtitle_path()
		except: pass

	def run_error(self, message=None):
		ku.clear_property(PROP_PLAY_OPENING)
		try:
			if not self.is_generic:
				self.sources_object.playback_successful = False
		except:
			pass
		self.clear_playback_properties(clear_navigation=not self.is_generic)
		if self.is_generic and ku.get_property('redlight.browse_playback') == 'true':
			return ku.notification('Playback Failed', 4000, settle_ms=400)
		# play_file walks the resolve queue and calls playback_failed_action after the last attempt.
		if not self.is_generic and getattr(self, 'sources_object', None):
			return
		text = message or 'This link could not be played. It may be expired, removed, or unsupported on this device.'
		ku.hide_busy_dialog()
		ku.sleep(400)
		try:
			return ku.kodi_dialog().ok('Playback failed', text)
		except Exception:
			try:
				return ku.ok_dialog(heading='Playback failed', text=text)
			except Exception:
				return ku.notification('Playback Failed', 4000, settle_ms=400)
